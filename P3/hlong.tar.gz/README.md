Name: Hanzhe Long
CS Login: hlong
Email: hlong25@wisc.edu
Status: finished
Resources used: lots of gpt4 to guide me how to implement pipe and bg/fg
