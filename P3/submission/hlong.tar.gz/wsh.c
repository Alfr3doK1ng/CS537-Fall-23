#include "wsh.h"

BackgroundJob bg_jobs[MAX_BACKGROUND_JOBS];
int bg_job_count = 0;

int is_builtin_command(char* cmd) {
    char* builtins[] = {"exit", "cd", "jobs", "fg", "bg"};
    for(int i = 0; i < 5; i++) {
        if(strcmp(cmd, builtins[i]) == 0) return 1;
    }
    return 0;
}

void execute_command(char** args) {
    if (is_builtin_command(args[0])) {
        if (strcmp(args[0], "exit") == 0) {
            exit(0);
        } else if (strcmp(args[0], "cd") == 0) {
            if (args[1]) {
                chdir(args[1]);
            } else {
                fprintf(stderr, "wsh: cd: missing argument\n");
            }
        } else if (strcmp(args[0], "jobs") == 0) {
            for (int i = 0; i < bg_job_count; i++) {
                printf("[%d] %s\n", i, bg_jobs[i].command);
            }
        }
        // TODO: Implement other built-ins like fg, bg
    } else {
        pid_t pid = fork();
        if (pid == 0) {
            execvp(args[0], args);
            perror("wsh");
            exit(1);
        } else {
            if (strstr(args[0], "&")) {
                bg_jobs[bg_job_count].pid = pid;
                strcpy(bg_jobs[bg_job_count].command, args[0]);
                bg_job_count++;
            } else {
                wait(NULL);
            }
        }
    }
}

void parse_input(char* input, char** args) {
    char* token = strtok(input, " \n");
    int i = 0;
    while (token != NULL) {
        args[i++] = token;
        token = strtok(NULL, " \n");
    }
    args[i] = NULL;
}

int main(int argc, char* argv[]) {
    char input[MAX_INPUT_SIZE];
    char* args[MAX_ARG_SIZE];

    while(1) {
        printf("wsh> ");
        fgets(input, MAX_INPUT_SIZE, stdin);

        parse_input(input, args);
        execute_command(args);
    }
    return 0;
}
